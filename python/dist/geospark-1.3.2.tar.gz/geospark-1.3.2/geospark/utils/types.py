from typing import Union


numeric = Union[float, int]
path = str
crs = str
